<style>
    .panel-title{
            font-family: inherit;
            font-size: 16px; 
            font-weight: bold;
        }
    .thla th {
        color: #173a18;
        text-align: left;
    }
    input[type="search"] {
        border:1px solid #8dc641;
    }
    
    .thla th:nth-child(1), .thla th:nth-child(2), .thla th:nth-child(3), .thla th:nth-child(4), .thla th:nth-child(5), .thla th:nth-child(6){
        border-right: 1px solid #a0a0a0;
        text-align: center;
    }
    .thla td:nth-child(1), .thla td:nth-child(2), .thla td:nth-child(3), .thla td:nth-child(4), .thla td:nth-child(5), .thla td:nth-child(6){
        border-right: 1px solid #a0a0a0;
    }
    table.dataTable thead th {
        border-bottom: 1px solid #a0a0a0!important;
    }
    #example {
        border: 1px solid #a0a0a0;
    }
    
    ul.tab {
        list-style-type: none;
        margin: 0;
        padding: 0;
        overflow: hidden;
        border: 1px solid #ccc;
        background-color: #DFF0D8;
    }

    /* Float the list items side by side */
    ul.tab li {float: left;}

    /* Style the links inside the list items */
    ul.tab li a {
        display: inline-block;
        color: #173a18;
        text-align: center;
        padding: 5px 10px;
        text-decoration: none;
        transition: 0.3s;
        font-size: 14px;
        font-weight: bold;
    }

    /* Change background color of links on hover */
    ul.tab li a:hover {
        background-color: #8dc641;
        color: #fff;
    }

    /* Create an active/current tablink class */
    ul.tab li a:focus, .active {
        background-color: #8dc641;
        color:#fff;
    }

    /* Style the tab content */
    .tabcontent {
        display: none;
        padding: 6px 12px;
        border: 1px solid #8dc641; 
    }
    .pr {
        padding-right: 0px;
      }
    .pl {
        padding-left: 0px;
    }
    .br-rdr {
        border-top-right-radius: 0px;
        border-bottom-right-radius: 0px;
    }
    .br-btn {
        border-top-left-radius: 0px;
        border-bottom-left-radius: 0px;
        border: 1px solid #ccc;
        line-height: 20px;
    }
</style>
<script type="text/javascript">
$(document).ready(function() {
    $('#example').DataTable( {
        "pagingType": "full_numbers"
    } );
} );
</script> 
<table id="example" class="display thla" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>Product Code</th>
            <th>Name</th> 
            <th>Stock</th>                       
            <th>Add to Cart</th>                       
        </tr>
    </thead>

    <tbody>

        <?php

            $i=0;

            foreach ($stockprodcucts as $stock): 
            $i++;
            
            $pid=$stock['Product']['id'];
            $description=/*$stock['Category']['name'].'->'.*/$stock['SubCategory']['name'].' - '.$stock['Product']['name'];
            $pdcodes=$stock['Category']['cCode'].$stock['SubCategory']['sCode'].$stock['Product']['productcode'];
            
            if(!empty($stock['Brand']['name'])){
                $description.=' - '.'<span title="Model" style="cursor:pointer">'.$stock['Brand']['name'].'</span>';
            }
            if(!empty($stock['Size']['name'])){
                $description.=' - '.'<span title="Size" style="cursor:pointer">'.$stock['Size']['name'].'</span>';
            }
            if(!empty($stock['Color']['name'])){
                $description.=' - '.'<span title="Color" style="cursor:pointer">'.$stock['Color']['name'].'</span>';
            }

            $cdate=date('Y-m-d');
            $pdate=date('Y-m-d', strtotime('-1 days'));
            $balance = $stock[0]['currentStock']; 
        ?>
        <?php if($balance >= 1){?>
        <tr>
            <td><?php echo $pdcodes; ?>&nbsp;</td>
            <td><?php  echo $description; ?></td>  
            <td><span id="pBalance<?php echo $pid;?>"><?= $balance; ?></span> <?= $stock['Measure']['name']; ?></td>
            <td>
                <div id="pi<?php echo $pid;?>" class="add-cart-button btn-group btn btn-primary" onclick="addCart('<?php echo $stock['Product']['id'] ?>', '<?php echo $stock['Product']['name'] ?>', '<?php echo $stock['Measure']['id'] ?>', '<?php echo $balance ?>');"> <i class=" glyphicon glyphicon-shopping-cart"></i>
                </div> 
            </td>
        </tr>
        <?php }?>
    <?php endforeach; ?>          
    <tbody>
</table>