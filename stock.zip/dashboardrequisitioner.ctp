
<style>
    
	.my-row{
		font-family: inherit;
		background:#083a81;
		padding:35px 10px 15px;
	}
	
	.my-4{
		background:#fff;
		width:100px; height:100px;
		text-align:center;
		display:block;
		color:#083a81;
		border-radius:50%;
		font-size:80px;
		font-weight:normal;
		float:left;
	}
	
	.my-easy{
		float:left;
	}
	
	.my-h1{
		color:#fff;
		margin:0px;
		display:block;
		font-size:35px;
		padding:20px 0px 0px 10px;
	}
	
	.my-h3 {
		color:#97e004;
		margin:0px;
		font-size:18px;
		display:block;
		padding:5px 0px;
                text-decoration: none;
	}
        .my-h3 a{
		color:#97e004;
		margin:0px;
		font-size:18px;
		display:block;
		padding:5px 0px;
                text-decoration: none;
	}
	
	.my-p{
		color:#0ca7f7;
		margin:0px;
		display:block;
		padding:10px;
	}
	
	.my-p-2{
		color:#fff;
		margin:0px;
		display:block;
		font-size:12px;
		white-space: nowrap;
	}
	
	.my-stp{
		color:#fff;
		width:20%;
		padding:0px 15px;
		float:left;
	}
	
	.my-stp-top{
		
	}
	
	.my-stp-btm{
		position:relative;
		display:none;
	}
	
	.my-stp span{
		background:#fff; color:#333;
		display:block; 
		text-align:center;
		font-size:16px; font-weight:bold;
		width:25px; height:25px;
		border-radius:50%;
		position:absolute;
		z-index:100;
		
	}
	
	.my-stp:hover .my-stp-top>i{
		background:#97e004; color:#fff;
		border:3px solid #97e004;
	}
	
	.my-stp:hover .my-stp-btm{
		display:block;
		cursor:pointer;
	}
	
	.my-stp i{
		border:3px solid #fff;
		width:70px !important; height:70px;
		padding:25px;
		border-radius:50%;
	}
	
	.my-active{
	}
	
	.my-active .my-stp-top>i{
		background:#97e004; color:#fff;
		border:3px solid #97e004;
	}
	.my-active .my-stp-btm{
		display:block;
		cursor:pointer;
	}
        .pn {
            margin: 0 auto;
            padding: 1px 0 12px;
            width: 24%;
            border-radius: 20px;
          }
        .pn h2{
            font-family: inherit;
            color: #fff; 
            font-size: 23px; 
            font-weight: bold;
            text-align: center;
        }
        .panel-title{
            font-family: inherit;
            font-size: 16px; 
            font-weight: bold;
        }
        .thla th {
               color: #0088cc;
               text-align: left;
           }
           
        
    @media screen and (max-width: 767px){
        
        .my-4{
		background:#fff;
		width:70px; height:70px;
		text-align:center;
		display:block;
		color:#083a81;
		border-radius:50%;
		font-size:50px;
		font-weight:normal;
		float:left;
	}
	
	.my-easy{
		float:left;
	}
	
	.my-h1{
		color:#fff;
		margin:0px;
		display:block;
		font-size:25px;
		padding:15px 0px 0px 8px;
	}
	
	.my-h3 {
		color:#97e004;
		margin:0px;
		font-size:10px;
		display:block;
		padding:5px 0px;
                text-decoration: none;
	}
        .my-h3 a{
		color:#97e004;
		margin:0px;
		font-size:10px;
		display:block;
		padding:5px 0px;
                text-decoration: none;
	}
        
        .my-stp i{
		border:3px solid #fff;
		width:50px !important; height:50px;
		padding:20px;
		border-radius:50%;
	}
        .pn {
            margin: 0 auto;
            padding: 1px 0 12px;
            width: 24%;
            border-radius: 20px;
          }
        .pn h2{
            font-family: inherit;
            color: #fff; 
            font-size: 12px; 
            font-weight: bold;
            text-align: center;
        }
        .panel-title{
            font-family: inherit;
            font-size: 16px; 
            font-weight: bold;
        }
        .thla th {
               color: #0088cc;
               text-align: left;
        }
          
    }
	
</style>


<style>

    .my_block{
		padding:10px;
		margin:10px;
		float:left;
		border-radius:10px;
		box-shadow:1px 1px 2px #ddd;
		text-align:center;
        height:180px;
        width: 100%;
    }
    .my_block_mid{
            padding:10px;
            margin:10px auto;
            border-radius:10px;
            box-shadow:1px 1px 2px #ddd;
            text-align:center;
            width:20%;
            height:150px;
    }

    .my_link_01{
            font-size:18px;
            margin:20px 0px 10px;
    }
	
	.my_badges{
		background:#fff;
		color:Red;
		width:60px;
		height:30px;
		margin:0px auto;
		border-radius:15px;
		padding-top:5px;
		font-weight:bold;
		box-shadow:-1px 1px 3px #111;
	}



    .my_color_green_01{
            background:#1b8428;
            color:#fff;
    }

    .my_color_green_02{
            background:#1b844a;
            color:#fff;
    }

    .my_color_green_03{
            background:#97e004;
            color:#fff;
    }
    
    .my_color_green_04{
            background:#478b0f;
            color:#fff;
    }
    .my_color_blue_01{
            background:#00bcd4;
            color:#fff;
    }
    .my_color_blue_02{
            background:#4765a0;
            color:#fff;
    }

    .my_color_red_01{
            background:#a40303;
            color:#fff;
    }
    .my_color_red_02{
            background:#fb8201;
            color:#fff;
    }

    .my_color_yellow_01{
            background:#f6d655;
            color:#fff;
    }
    .my_color_yellow_02{
            background:#efcb07;
            color:#fff;
            text-shadow:1px 1px 1px #79510b;
    }
    
    .my_color_purple_01{
        background:#b02de6;
        color:#FFF;
    }


    .my_color_01{
        background:#009abf;
        color:#fff;
    }

    .my_color_02{
        background:#00c0ef;
        color:#fff;
    }

    .my_color_03{
        background:#008548;
        color:#fff;
    }

    .my_color_04{
        background:#00a65a;
        color:#fff;
    }

    .my_color_05{
        background:#c27d0e;
        color:#fff;
    }

    .my_color_06{
        background:#f39c12;
        color:#fff;
    }
    .my_color_06 img{ 
        border: 2px solid #FFF;
        border-radius: 50%;
        padding: 4px;
    }
    .my_color_07{
        background:#269696;
        color:#fff;
    }

    .my_color_08{
        background:#30bbbb;
        color:#fff;
    }


	/*
    @media screen and (min-width: 1001px){
            .my_block{
                    width:84px;
            }
    }

    @media screen and (min-width: 800px) and (max-width: 1000px)  {
            .my_block{
                    width:30%;
            }
    }

    @media screen and (min-width: 650px) and (max-width: 800px)  {
            .my_block{
                    width:45%;
            }
    }

    @media screen and (max-width: 649px)  {
            .my_block{
                    width:90%;
            }
    }
	*/


</style>

<!-- <div class="row my-row">
    <div class="col-md-5 col-sm-4 clearfix">
        <div class="my-4"> 5 </div>
        <div class="my-easy ">
            <h1 class="my-h1">EASY STEPS</h1>
            <p class="my-p">From Product Entry to Delivery</p>
        </div>	
    </div>
    
    <div class="col-md-6 col-sm-8"> 
        
       <?php if($currentUser['role_id']==3) {?>
        
        <div class="my-stp">
            <div class="my-stp-top">
                <span>1</span>
                <i class="glyphicon glyphicon-star-empty"></i>
            </div>
             
            <div class="my-stp-btm">
                <h3 class="my-h3">PRODUCT ENTRY</h3>
                <p class="my-p-2">By Store</p>
            </div>
        </div>

        <div class="my-stp my-active">
            <div class="my-stp-top">
                <span>2</span>
                <i class="glyphicon glyphicon-star-empty"></i>
            </div>

            <div class="my-stp-btm">
                <h3 class="my-h3">
                    <?php echo $this->Html->link('STOCK LIST', array('controller' => 'stocks', 'action' => 'stockrequisition')); ?>
                </h3>
                <p class="my-p-2">For All</p>
            </div>
        </div>
        
        <div class="my-stp my-active">
            <div class="my-stp-top">
                <span>3</span>
                <i class="glyphicon glyphicon-star-empty"></i>
            </div>

            <div class="my-stp-btm">
                <h3 class="my-h3">
                    <?php echo $this->Html->link('REQUISITION', array('controller'=>'requisitions', 'action'=> 'index')); ?>
                </h3>
                <p class="my-p-2">For Requisitioner</p>
            </div>
        </div>
                     
        <div class="my-stp">
            <div class="my-stp-top">
                <span>4</span>
                <i class="glyphicon glyphicon-star-empty"></i>
            </div>

            <div class="my-stp-btm">
                <h3 class="my-h3">APPROVAL</h3>
                <p class="my-p-2">By Admin</p>
            </div>
        </div>
                
        <div class="my-stp">
            <div class="my-stp-top">
                <span>5</span>
                <i class="glyphicon glyphicon-star-empty"></i>
            </div>

            <div class="my-stp-btm">
                <h3 class="my-h3">DELIVERY</h3>
                <p class="my-p-2">By Storekeeper</p>
            </div>
        </div>
        <?php }?>
    </div>
</div>
<br> -->


<div class="clearfix">   
    <div class="col-sm-12" style="margin-top: 15px;">
        <div class="row">             
            <div class="col-md-4">
				<a href="<?php echo $this->webroot;?>stocks/atcrequisition">
				<div class="my_block my_color_01">
					<img src="<?php echo $this->webroot; ?>img/my_icons/stock.png" width="50px" /> <br>
					<p class="my_link_01"> Requisition </p>
					<p class="my_badges"> New </p>
				</div>
				</a>
			</div>
			
			<div class="col-md-4">
				<a href="<?php echo $this->webroot;?>requisitions/requisitionreceived"> 
				<div class="my_block my_color_01">
					<img src="<?php echo $this->webroot; ?>img/my_icons/requisitioner.png" width="50px" /> <br>
					<p class="my_link_01"> My Requisition </p>
					<p class="my_badges">  <?php echo $totalreqcount;?>  </p>
				</div>
				</a>
			</div>
			
			<div class="col-md-4">
				<a href="<?php echo $this->webroot;?>Stocks/availablestock">
				<div class="my_block my_color_03">
					<img src="<?php echo $this->webroot; ?>img/my_icons/stock.png" width="50px" /> <br>
					<p class="my_link_01"> Product Stock </p>
				</div>
				</a>
			</div>
			
		</div>
		
		<div class="row">             
            <div class="col-md-4">
				<a href="<?php echo $this->webroot;?>requisitions/requisitionapprove"> 
				<div class="my_block my_color_04">
					<img src="<?php echo $this->webroot; ?>img/my_icons/approved.png" width="50px" /> <br>
					<p class="my_link_01"> Requisition Approved </p>
					<p class="my_badges">  <?php echo $approvedcount;?>  </p>
				</div>
				</a>
			</div> 			
			<div class="col-md-4">
				<a href="<?php echo $this->webroot;?>requisitions/requisitionpending"> 
				<div class="my_block my_color_06">
					<img src="<?php echo $this->webroot; ?>img/my_icons/hanger.png" width="50px" /> <br>
					<p class="my_link_01" > Pending Requisition </p>
					<p class="my_badges">  <?php echo $pendingcount;?>  </p>
				</div>
			</div>

			<div class="col-md-4">
				<a href="<?php echo $this->webroot;?>requisitions/requisitiondelivery"> 
				<div class="my_block my_color_02">
					<img src="<?php echo $this->webroot; ?>img/my_icons/d1.png" width="50px" /> <br>
					<p class="my_link_01" > Delivered </p>
					<p class="my_badges">  <?php echo $deliveredecount;?>  </p>
				</div>
			</div>
			
		</div>
		<div class="row">
			<div class="col-md-4">
			</div>
			<div class="col-md-4">
				<a href="<?php echo $this->webroot;?>requisitiondetails/requisitionreject">
				<div class="my_block my_color_05">
					<img src="<?php echo $this->webroot; ?>img/my_icons/not_approved.png" width="50px" /> <br>
					<p class="my_link_01">Requisitions Rejected </p>
					<p class="my_badges">  <?php echo $rejectedecount;?>  </p>
				</div>
				</a>
			</div>
		</div>
    </div>
	
<!--	<a href="<?php echo $this->webroot;?>requisitions/#"> 
	<div class="my_block my_color_red_02">
		<img src="<?php echo $this->webroot; ?>img/my_icons/pending.png" width="50px" /> <br>
		<p class="my_link_01" > Pending List </p>
	</div>
	</a>-->
    
</div>