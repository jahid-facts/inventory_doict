<style>
    .nav > li > a {
        padding: 0px!important;
    }
    .panel-title{
            font-family: inherit;
            font-size: 16px; 
            font-weight: bold;
        }
    .thla th {
        color: #173a18;
        text-align: left;
    }
    input[type="search"] {
        border:1px solid #8dc641;
    }
    
    .thla th:nth-child(1), .thla th:nth-child(2), .thla th:nth-child(3){
        border-right: 1px solid #a0a0a0;
        text-align: center;
    }
    .thla th:nth-child(4){ 
        text-align: center;
    }
    .thla td:nth-child(1), .thla td:nth-child(2), .thla td:nth-child(3){
        border-right: 1px solid #a0a0a0;
        text-align: center;
    }
    .thla td:nth-child(4){ 
        text-align: center;
    }
    table.dataTable thead th {
        border-bottom: 1px solid #a0a0a0!important;
    }
    #example {
        border: 1px solid #a0a0a0;
    }
    
    ul.tab {
        list-style-type: none;
        margin: 0;
        padding: 0;
        overflow: hidden;
        border: 1px solid #ccc;
        background-color: #DFF0D8;
    }

    /* Float the list items side by side */
    ul.tab li {float: left;}

    /* Style the links inside the list items */
    ul.tab li a {
        display: inline-block;
        color: #173a18;
        text-align: center;
        padding: 5px 10px;
        text-decoration: none;
        transition: 0.3s;
        font-size: 14px;
        font-weight: bold;
    }

    /* Change background color of links on hover */
    ul.tab li a:hover {
        background-color: #8dc641;
        color: #fff;
    }

    /* Create an active/current tablink class */
    ul.tab li a:focus, .active {
        background-color: #8dc641;
        color:#fff;
    }

    /* Style the tab content */
    .tabcontent {
        display: none;
        padding: 6px 12px;
        border: 1px solid #8dc641; 
    }
    .pr {
        padding-right: 0px;
      }
    .pl {
        padding-left: 0px;
    }
    .br-rdr {
        border-top-right-radius: 0px;
        border-bottom-right-radius: 0px;
    }
    .br-btn {
        border-top-left-radius: 0px;
        border-bottom-left-radius: 0px;
        border: 1px solid #ccc;
        line-height: 20px;
    }
    .btn-primary { 
      border:0px!important; 
    }
    .message {
        margin: 5px 0px;
        background: #f2f3f7;
        padding: 4px;
        color: #2d6f2d;
        text-align: center;
        font-size: 20px;
    }
    .loader-overlay {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: rgba(255, 255, 255, 0.8);
        padding: 10px;
        border-radius: 8px;
        z-index: 999;
    }

    .loader {
        border: 4px solid #f3f3f3;
        border-top: 4px solid #3498db;
        border-radius: 50%;
        width: 30px;
        height: 30px;
        animation: spin 1s linear infinite;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
</style>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">
<script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
    var path='<?php echo $this->webroot;?>';
    function getCategory(id){
        $('.othetcat').append('<div class="loader-overlay"><div class="loader"></div></div>');
        $.ajax({    
            type: 'POST',
            url: path +'stocks/getcategorycart',
            data: {id:id},
            success: function(data){
                $('.thla').remove();
                $('.othetcat').html(data);
            }
        });
    }
</script>


<div class="user index">
    <div style="height:20px;"></div>
    
    <div class="panel panel-primary">
        <div class="panel-heading">
          <h3 class="panel-title"> <?php echo __('New Requisitions'); ?> </h3>
        </div>
        <div class="panel-body">
            <div class="col-sm-10 col-sm-offset-1">   
                <?php echo $this->Session->flash(); ?>        
                <?php echo $this->Form->create ('Report', array ('name' => 'form') ); ?> 
                <div style="clear: both; height: 15px;"></div> 
                
                <ul class="tab">
                     <li class="active"><a href="javascript:void(0)" onclick="getCategory(0);"  class="tablinks" >All Products</a></li>
                    <li ><a href="javascript:void(0)" style="display: none;"  class="tablinks"   onclick="openCity(event, 'AllProducts')" id="defaultOpen">All Products</a></li>
                    
                    <?php
                    
                        foreach ($categories as $category): 
                            $imgId=$category['Category']['id'];
                    ?>
                    
                    <li><a href="javascript:void(0)" class="tablinks" onclick="getCategory(<?php echo $imgId;?>)" ><?php echo $category['Category']['name'];?></a></li>
                    
                    <?php endforeach; ?>
                    
                </ul>
                
                
              
            
            
                <div id="AllProducts" class="tabcontent">    
                    <div class="table-responsive">
                        <div class="thla">
                            <script type="text/javascript">
                                $(document).ready(function() {
                                    $('#example').DataTable( {
                                        "pagingType": "full_numbers"
                                    } );
                                } );
                            </script> 
                        
                            <table id="example" class="display" cellspacing="0" width="100%">
                                <thead>
                                    <tr>
                                        <th>Product Code</th>
                                        <th>Name</th> 
                                        <th>Stock</th>                       
                                        <th>Add to Cart</th>                       
                                    </tr>
                                </thead>

                                <tbody>

                                    <?php

                                        $i=0;

                                        foreach ($stockprodcucts as $stock): 
                                        $i++;
                                        //echo p($stock);
                                        $pid=$stock['Product']['id'];
                                        $description=/*$stock['Category']['name'].'->'.*/$stock['SubCategory']['name'].' - '.$stock['Product']['name'];
                                        $pdcodes=$stock['Category']['cCode'].$stock['SubCategory']['sCode'].$stock['Product']['productcode'];
                                        
                                        if(!empty($stock['Brand']['name'])){
                                            $description.=' - '.'<span title="Model" style="cursor:pointer">'.$stock['Brand']['name'].'</span>';
                                        }
                                        if(!empty($stock['Size']['name'])){
                                            $description.=' - '.'<span title="Size" style="cursor:pointer">'.$stock['Size']['name'].'</span>';
                                        }
                                        if(!empty($stock['Color']['name'])){
                                            $description.=' - '.'<span title="Color" style="cursor:pointer">'.$stock['Color']['name'].'</span>';
                                        }

                                        $cdate=date('Y-m-d');
                                        
                                        $pdate=date('Y-m-d', strtotime('-1 days'));
                                        
                                        
                                       $sql  = "SELECT pt.name, pt.id, pt.measure_id, s.squantity, p.pquantity, rd.rdquantity, d.dquantity, dm.dmquantity, rr.rrquantity 
                                            FROM products AS pt 
                                            LEFT JOIN 
                                            ( 
                                                SELECT stocks.product_id, SUM(stocks.quantity) AS squantity 
                                                FROM stocks 
                                                GROUP BY stocks.product_id 
                                            ) AS s ON pt.id = s.product_id 
                                            LEFT JOIN 
                                            ( 
                                                SELECT purchasedetails.product_id, SUM(purchasedetails.quantity) AS pquantity 
                                                FROM purchasedetails 
                                                GROUP BY purchasedetails.product_id 
                                            ) AS p ON pt.id = p.product_id 
                                            LEFT JOIN 
                                            ( 
                                                SELECT requisitiondetails.product_id, SUM(requisitiondetails.quantity) AS rdquantity 
                                                FROM requisitiondetails 
                                                WHERE requisitiondetails.status IN (1, 2) 
                                                GROUP BY requisitiondetails.product_id 
                                            ) AS rd ON pt.id = rd.product_id 
                                            LEFT JOIN 
                                            ( 
                                                SELECT deliverydetails.product_id, SUM(deliverydetails.quantity) AS dquantity 
                                                FROM deliverydetails 
                                                GROUP BY deliverydetails.product_id 
                                            ) AS d ON pt.id = d.product_id 
                                            LEFT JOIN 
                                            ( 
                                                SELECT requisitionreturns.product_id, SUM(requisitionreturns.quantity) AS rrquantity 
                                                FROM requisitionreturns 
                                                GROUP BY requisitionreturns.product_id 
                                            ) AS rr ON pt.id = rr.product_id 
                                            LEFT JOIN 
                                            ( 
                                                SELECT damages.product_id, SUM(damages.quantity) AS dmquantity 
                                                FROM damages 
                                                GROUP BY damages.product_id 
                                            ) AS dm ON pt.id = dm.product_id 
                                            WHERE pt.id = '".$pid."' 
                                            GROUP BY pt.id, pt.name, pt.measure_id";
                                            
                                        $data = getQueryData($sql);
                                        $stockIn = ($data['squantity']+$data['pquantity']+$data['rrquantity']);
                                        $stockOut = ($data['rdquantity']+$data['dquantity']+$data['dmquantity']);
                                        $balance = $stockIn - $stockOut;
                                    ?>

                                    <?php if($balance >= 1){?>
                                    <tr>
                                        <td><?php echo $pdcodes; ?>&nbsp;</td>
                                        <td>
                                            <?php  echo $description; ?>
                                        </td>  
                                        <td><span id="pBalance<?php echo $pid;?>"><?= $balance; ?></span> <?= $stock['Measure']['name']; ?></td>  
                                        <td>
                                            <div id="pi<?php echo $pid;?>" class="add-cart-button btn-group btn btn-primary" onclick="addCart('<?php echo $stock['Product']['id'] ?>', '<?php echo $stock['Product']['name'] ?>', '<?php echo $stock['Measure']['id'] ?>', '<?php echo $balance ?>');">
                                                <i class=" glyphicon glyphicon-shopping-cart"></i>
                                            </div> 
                                        </td>
                                    </tr>
                                    <?php }?>
                                <?php endforeach; ?>          
                                <tbody>
                            </table>
                        </div>
                        <div class="othetcat"></div>
                    </div>
                </div>
                <?php foreach ($categories as $category):  $imgId=$category['Category']['id']; ?>

                    <div id=$imgId class="tabcontent">
                        <h3>Stationary</h3>
                        <p>Paris is the capital of France.</p>
                    </div>
                                  
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>


<!--Tab Link Start-->
<script>
function openCity(evt, cityName) {


    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}


document.getElementById("defaultOpen").click();
</script>


<!--Tab Link End-->